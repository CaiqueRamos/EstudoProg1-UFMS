public class Cartao
{
	private String nome;
	private String senha;
	private double credito;

	public void terNome (String n)
	{
		this.nome = n;
	}

}