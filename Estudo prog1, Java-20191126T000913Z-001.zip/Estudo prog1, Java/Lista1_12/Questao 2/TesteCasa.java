import java.util.Scanner;
public class TesteCasa
{
	public static void main(String []args)
	{
		Casa cas = new Casa();
		Scanner teclado = new Scanner(System.in);
		cas.abrirTodasPortas();
		cas.setPorta1();
		cas.quantasPortasAbertas();
		


	}
	
}